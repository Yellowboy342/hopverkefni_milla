﻿namespace Hopverkefni
{
    partial class btnNyrLekur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTveir9 = new System.Windows.Forms.Button();
            this.btnTveir8 = new System.Windows.Forms.Button();
            this.btnTveir7 = new System.Windows.Forms.Button();
            this.btnTveir4 = new System.Windows.Forms.Button();
            this.btnTveir5 = new System.Windows.Forms.Button();
            this.btnTveir6 = new System.Windows.Forms.Button();
            this.btnTveir11 = new System.Windows.Forms.Button();
            this.btnTveir2 = new System.Windows.Forms.Button();
            this.btnTveir3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nýrLeikurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbSigur = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTveir9
            // 
            this.btnTveir9.BackColor = System.Drawing.Color.White;
            this.btnTveir9.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTveir9.Location = new System.Drawing.Point(457, 313);
            this.btnTveir9.Name = "btnTveir9";
            this.btnTveir9.Size = new System.Drawing.Size(113, 104);
            this.btnTveir9.TabIndex = 8;
            this.btnTveir9.UseVisualStyleBackColor = false;
            this.btnTveir9.Click += new System.EventHandler(this.btnTveir1);
            // 
            // btnTveir8
            // 
            this.btnTveir8.BackColor = System.Drawing.Color.White;
            this.btnTveir8.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTveir8.Location = new System.Drawing.Point(346, 313);
            this.btnTveir8.Name = "btnTveir8";
            this.btnTveir8.Size = new System.Drawing.Size(113, 104);
            this.btnTveir8.TabIndex = 9;
            this.btnTveir8.UseVisualStyleBackColor = false;
            this.btnTveir8.Click += new System.EventHandler(this.btnTveir1);
            // 
            // btnTveir7
            // 
            this.btnTveir7.BackColor = System.Drawing.Color.White;
            this.btnTveir7.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTveir7.Location = new System.Drawing.Point(235, 313);
            this.btnTveir7.Name = "btnTveir7";
            this.btnTveir7.Size = new System.Drawing.Size(113, 104);
            this.btnTveir7.TabIndex = 10;
            this.btnTveir7.UseVisualStyleBackColor = false;
            this.btnTveir7.Click += new System.EventHandler(this.btnTveir1);
            // 
            // btnTveir4
            // 
            this.btnTveir4.BackColor = System.Drawing.Color.White;
            this.btnTveir4.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTveir4.Location = new System.Drawing.Point(235, 211);
            this.btnTveir4.Name = "btnTveir4";
            this.btnTveir4.Size = new System.Drawing.Size(113, 104);
            this.btnTveir4.TabIndex = 11;
            this.btnTveir4.UseVisualStyleBackColor = false;
            this.btnTveir4.Click += new System.EventHandler(this.btnTveir1);
            // 
            // btnTveir5
            // 
            this.btnTveir5.BackColor = System.Drawing.Color.White;
            this.btnTveir5.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTveir5.Location = new System.Drawing.Point(346, 211);
            this.btnTveir5.Name = "btnTveir5";
            this.btnTveir5.Size = new System.Drawing.Size(113, 104);
            this.btnTveir5.TabIndex = 12;
            this.btnTveir5.UseVisualStyleBackColor = false;
            this.btnTveir5.Click += new System.EventHandler(this.btnTveir1);
            // 
            // btnTveir6
            // 
            this.btnTveir6.BackColor = System.Drawing.Color.White;
            this.btnTveir6.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTveir6.Location = new System.Drawing.Point(457, 211);
            this.btnTveir6.Name = "btnTveir6";
            this.btnTveir6.Size = new System.Drawing.Size(113, 104);
            this.btnTveir6.TabIndex = 13;
            this.btnTveir6.UseVisualStyleBackColor = false;
            this.btnTveir6.Click += new System.EventHandler(this.btnTveir1);
            // 
            // btnTveir11
            // 
            this.btnTveir11.BackColor = System.Drawing.Color.White;
            this.btnTveir11.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTveir11.Location = new System.Drawing.Point(235, 109);
            this.btnTveir11.Name = "btnTveir11";
            this.btnTveir11.Size = new System.Drawing.Size(113, 104);
            this.btnTveir11.TabIndex = 14;
            this.btnTveir11.UseVisualStyleBackColor = false;
            this.btnTveir11.Click += new System.EventHandler(this.btnTveir1);
            // 
            // btnTveir2
            // 
            this.btnTveir2.BackColor = System.Drawing.Color.White;
            this.btnTveir2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTveir2.Location = new System.Drawing.Point(346, 109);
            this.btnTveir2.Name = "btnTveir2";
            this.btnTveir2.Size = new System.Drawing.Size(113, 104);
            this.btnTveir2.TabIndex = 15;
            this.btnTveir2.UseVisualStyleBackColor = false;
            this.btnTveir2.Click += new System.EventHandler(this.btnTveir1);
            // 
            // btnTveir3
            // 
            this.btnTveir3.BackColor = System.Drawing.Color.White;
            this.btnTveir3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTveir3.Location = new System.Drawing.Point(457, 109);
            this.btnTveir3.Name = "btnTveir3";
            this.btnTveir3.Size = new System.Drawing.Size(113, 104);
            this.btnTveir3.TabIndex = 16;
            this.btnTveir3.UseVisualStyleBackColor = false;
            this.btnTveir3.Click += new System.EventHandler(this.btnTveir1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(366, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 33);
            this.label1.TabIndex = 17;
            this.label1.Text = "Mylla";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightGreen;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(843, 24);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nýrLeikurToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.menuToolStripMenuItem.Text = "Valmynd";
            // 
            // nýrLeikurToolStripMenuItem
            // 
            this.nýrLeikurToolStripMenuItem.Name = "nýrLeikurToolStripMenuItem";
            this.nýrLeikurToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.nýrLeikurToolStripMenuItem.Text = "Nýr leikur";
            this.nýrLeikurToolStripMenuItem.Click += new System.EventHandler(this.nýrLeikurToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.exitToolStripMenuItem.Text = "Hætta";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(648, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 25);
            this.label3.TabIndex = 21;
            this.label3.Text = "X stig:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(648, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 25);
            this.label4.TabIndex = 22;
            this.label4.Text = "O stig:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(733, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 25);
            this.label2.TabIndex = 23;
            this.label2.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(733, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 25);
            this.label5.TabIndex = 24;
            this.label5.Text = "0";
            // 
            // tbSigur
            // 
            this.tbSigur.BackColor = System.Drawing.Color.White;
            this.tbSigur.Enabled = false;
            this.tbSigur.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSigur.ForeColor = System.Drawing.Color.Black;
            this.tbSigur.Location = new System.Drawing.Point(576, 266);
            this.tbSigur.Multiline = true;
            this.tbSigur.Name = "tbSigur";
            this.tbSigur.Size = new System.Drawing.Size(255, 56);
            this.tbSigur.TabIndex = 25;
            this.tbSigur.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnNyrLekur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(843, 456);
            this.Controls.Add(this.tbSigur);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnTveir3);
            this.Controls.Add(this.btnTveir2);
            this.Controls.Add(this.btnTveir11);
            this.Controls.Add(this.btnTveir6);
            this.Controls.Add(this.btnTveir5);
            this.Controls.Add(this.btnTveir4);
            this.Controls.Add(this.btnTveir7);
            this.Controls.Add(this.btnTveir8);
            this.Controls.Add(this.btnTveir9);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.Black;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "btnNyrLekur";
            this.ShowIcon = false;
            this.Text = "Mylla";
            this.Load += new System.EventHandler(this.btnNyrLekur_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTveir9;
        private System.Windows.Forms.Button btnTveir8;
        private System.Windows.Forms.Button btnTveir7;
        private System.Windows.Forms.Button btnTveir4;
        private System.Windows.Forms.Button btnTveir5;
        private System.Windows.Forms.Button btnTveir6;
        private System.Windows.Forms.Button btnTveir11;
        private System.Windows.Forms.Button btnTveir2;
        private System.Windows.Forms.Button btnTveir3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nýrLeikurToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbSigur;
    }
}

